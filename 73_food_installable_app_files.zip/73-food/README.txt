73 FOOD — PWA UPDATE
Upload these four files to the ROOT of the existing GitHub repository:
- index.html (replace existing)
- manifest.webmanifest
- service-worker.js
- icon.svg

The manifest and service worker make 73 Food installable as a home-screen app.
After GitHub Pages deploys, iPhone/iPad users open the website in Safari, tap Share, then Add to Home Screen. Android users can use the browser menu > Install app / Add to Home screen.

IMPORTANT: Shared live editing still requires Firebase setup in index.html. Do not announce the app as fully shared until Firebase config and database rules are set up and tested. The current no-login room URL is editable by anyone who has the link; treat it as a private family link and do not store sensitive information.
